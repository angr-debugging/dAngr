
```
load 'home_security'
cfgs
```