```
load 'dfs_bfs_demo'

```