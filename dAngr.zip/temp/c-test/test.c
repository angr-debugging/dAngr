// list_addrs.c
#define _GNU_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ifaddrs.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>

void test_function2(int arg1){
    printf("Argument value: %d\n", arg1);
}

void test_function(int arg0){
    printf("Argument value: %d\n", arg0);

    int arg1 =52;

    test_function2(arg1);

    printf("Argument value: %d\n", arg0);
}


int main(){
    int arg0 = 42;

    test_function(arg0);
    return 0;
}

/*int main(){
    //open file
     FILE *f = fopen("turnserver.conf", "r");
    if (f == NULL) {
        perror("Error opening file");
        return -1;
    }

    char line[1024];

    // use fgets to read line by line
    for (;;) {
        char *s = fgets(line, sizeof(line) - 1, f);
        if (!s) {
          break;
        }
        printf("%s", line);
    }
    return 0;
}

static void print_bytes(const void *p, size_t n) {
    const unsigned char *b = (const unsigned char *)p;
    for (size_t i = 0; i < n; ++i) {
        printf("%02x%s", b[i], (i + 1 < n) ? " " : "");
    }
}

int main(void) {
    struct event_base *base = event_base_new();
    if (!base) {
        perror("event_base_new");
        return 1;
    }

    // Pick any timeout you like; libevent may normalize it internally.
    struct timeval want = { .tv_sec = 5, .tv_usec = 123456 };
    const struct timeval *ptv = event_base_init_common_timeout(base, &want);

    printf("sizeof(tv_sec)=%zu, sizeof(tv_usec)=%zu\n",
           sizeof(ptv->tv_sec), sizeof(ptv->tv_usec));

    printf("tv_sec  bytes: ");
    print_bytes(&ptv->tv_sec, sizeof(ptv->tv_sec));
    printf("\n");

    printf("tv_usec bytes: ");
    print_bytes(&ptv->tv_usec, sizeof(ptv->tv_usec));
    printf("\n");

    event_base_free(base);
    return 0;
}*/

/*#include <event2/event.h>

#if defined(__linux__)
  #include <malloc.h>          // malloc_usable_size (glibc)
#elif defined(__APPLE__)
  #include <malloc/malloc.h>   // malloc_size
#elif defined(_WIN32)
  #include <malloc.h>          // _msize
#endif

static size_t heap_block_size(void *p) {
#if defined(__linux__)
    return malloc_usable_size(p);  // may be >= requested size
#elif defined(__APPLE__)
    return malloc_size(p);
#elif defined(_WIN32)
    return _msize(p);
#else
    return 0; // unknown platform
#endif
}

static void hexdump(const void *data, size_t size, size_t max_preview) {
    const unsigned char *p = (const unsigned char *)data;
    if (size > max_preview) size = max_preview;

    for (size_t i = 0; i < size; ++i) {
        if (i % 16 == 0) printf("%08zx  ", i);
        printf("%02x ", p[i]);
        if (i % 16 == 15 || i + 1 == size) {
            // ASCII gutter
            size_t line_start = i - (i % 16);
            size_t line_end   = i;
            // pad if short line
            for (size_t j = (i % 16) + 1; j <= 15; ++j) printf("   ");
            printf(" |");
            for (size_t j = line_start; j <= line_end; ++j) {
                unsigned char c = p[j];
                printf("%c", (c >= 32 && c < 127) ? c : '.');
            }
            printf("|\n");
        }
    }
}

int main(void) {
    struct event_config *cfg = event_config_new();
    if (!cfg) { fprintf(stderr, "event_config_new failed\n"); return 1; }

    event_config_set_flag(cfg, EVENT_BASE_FLAG_IGNORE_ENV);

    struct event_base *base = event_base_new_with_config(cfg);
    event_config_free(cfg);
    if (!base) { fprintf(stderr, "event_base_new_with_config failed\n"); return 1; }

    size_t sz = heap_block_size(base);
    if (sz == 0) {
        // Fallback: guess (dangerous). You can change this, but bigger guesses risk reading past the allocation.
        sz = 4096;
        fprintf(stderr, "WARNING: allocator size unknown; using fallback guess of %zu bytes\n", sz);
    }

    printf("Dumping %zu bytes from event_base @ %p\n", sz, (void*)base);

    // Preview: first 256 bytes to stdout
    hexdump(base, sz, 256);

    // Full dump to file
    FILE *f = fopen("event_base.dump", "wb");
    if (!f) { perror("fopen"); event_base_free(base); return 1; }
    size_t wrote = fwrite(base, 1, sz, f);
    fclose(f);
    printf("Wrote %zu bytes to event_base.dump\n", wrote);

    event_base_free(base);
    return 0;
}
*/

/*
static void hexdump(const void *data, size_t len) {
    const unsigned char *p = (const unsigned char *)data;
    for (size_t i = 0; i < len; i++) {
        printf("%02X", p[i]);
        if ((i + 1) % 16 == 0 || i + 1 == len) {
            if (i + 1 != len) printf("\n");
        } else {
            printf(" ");
        }
    }
    printf("\n");
}

int main(void) {
    struct ifaddrs *ifs = NULL;

    if (getifaddrs(&ifs) != 0) {
        perror("getifaddrs");
        return 1;
    }

    for (struct ifaddrs *ifa = ifs; ifa != NULL; ifa = ifa->ifa_next) {
        if (!ifa->ifa_addr) continue;         // no address
        if (!ifa->ifa_flags) continue;         // flags not set (paranoia)

        sa_family_t fam = ifa->ifa_addr->sa_family;

        // Show interface name and family
        printf("Interface: %s\n", ifa->ifa_name);

        if (fam == AF_INET) {
            // IPv4
            struct sockaddr_in *sa4 = (struct sockaddr_in *)ifa->ifa_addr;
            char buf[INET_ADDRSTRLEN] = {0};
            if (inet_ntop(AF_INET, &sa4->sin_addr, buf, sizeof(buf))) {
                printf("  Family: AF_INET\n");
                printf("  IP address: %s\n", buf);
            } else {
                perror("inet_ntop(AF_INET)");
            }

            // Raw bytes of the sockaddr_in
            printf("  Raw sockaddr_in (%zu bytes) in hex:\n", sizeof(*sa4));
            hexdump(sa4, sizeof(*sa4));
        }

    }
    freeifaddrs(ifs);
    return 0;
}*/