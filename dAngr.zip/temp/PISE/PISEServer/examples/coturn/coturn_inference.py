import logging
import angr
from angr import SimProcedure

from pise import sym_execution, server, hooks

class TurnSendHook(hooks.SendReceiveCallSite):

    def get_return_value(self, buff, length, call_context):
        length = call_context.state.regs.rax

    def set_hook(self, p):
        p.hook_symbol('udp_send', hooks.SendHook(self))

    def extract_arguments(self, call_context):
        length = call_context.state.regs.ecx
        buffer = call_context.state.regs.rdx
        return buffer, length


class TurnRecvHook(hooks.SendReceiveCallSite):

    def get_return_value(self, buff, length, call_context):
        return 0

    def set_hook(self, p):
        p.hook_symbol('read_spare_buffer', hooks.RecvHook(self))

    def extract_arguments(self, call_context):
        length = call_context.state.solver.BVV(0x10000, 64)
        buffer = call_context.state.solver.BVV(0x0049d4a0, 64)
        return buffer, length


def main():
    logging.getLogger('pise').setLevel(logging.DEBUG)
    query_runner = sym_execution.QueryRunner('../../file_state_4', [TurnSendHook(), TurnRecvHook()], True)
    s = server.Server(query_runner)
    s.listen()


if __name__ == "__main__":
    main()
