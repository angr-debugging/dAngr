# Man pages

After installation, the man page turnserver(1) must be available. The man page 
is located in man/man1 subdirectory. If you want to see the man page without 
installation, run the command:

	$	man -M man turnserver

HTML-formatted client library functions reference is located in docs/html 
subdirectory of the original archive tree. After the installation, it will 
be placed in PREFIX/share/doc/turnserver/html.
