# CLIENT API LIBRARY

The compilation process will create lib/ sub-directory with libturnclient.a 
library. The header files for this library are located in include/turn/client/ 
sub-directory. The C++ wrapper for the messaging functionality is located in 
TurnMsgLib.h header. An example of C++ code can be found in stunclient.c file. 
This file is compiled as a C++ program if C++ compiler is used, and as a C 
program if C compiler is used.
