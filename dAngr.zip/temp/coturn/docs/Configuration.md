# TURN Server setup

Read the project wiki pages: https://github.com/coturn/coturn/wiki

Also, check the project from page links to the TURN/WebRTC configuration examples.
It may give you an idea how it can be done.