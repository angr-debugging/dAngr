# Performance tuning

This topic is covered in the wiki page:

https://github.com/coturn/coturn/wiki/TURN-Performance-and-Load-Balance