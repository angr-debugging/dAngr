## STATIC LINK
make clean

make   CPPFLAGS="-DSQLITE_OMIT_LOAD_EXTENSION"   DBLIBS="-static -Wl,--start-group -lsqlite3 -Wl,--end-group"   LDFLAGS="-static \
            -Wl,--start-group \
            -levent_core -levent_extra -levent_openssl -levent_pthreads -levent \
            -lssl -lcrypto \
            -lsqlite3 -lz -lm \
            -lpthread -lrt -lresolv -ldl \
            -Wl,--end-group"

## DYNAMIC