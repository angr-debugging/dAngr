#!/usr/bin/env python3
# turn_variety_pcap.py
#
# Send a variety of STUN/TURN (UDP) messages to a TURN server and optionally
# capture a PCAP of the exchange. Also optionally dumps each client request
# as a raw file for use as AFLNet seeds.

import argparse
import socket
import struct
import threading
import time
import hmac
import hashlib
import binascii
import os
from typing import List, Tuple, Dict, Optional
from scapy.all import sniff, wrpcap, get_if_list, get_if_addr  # type: ignore

# ---------- Constants ----------
STUN_MAGIC_COOKIE = 0x2112A442
STUN_HEADER_SIZE = 20

# Methods (RFC 5389/5766)
M_BINDING           = 0x001
M_ALLOCATE          = 0x003
M_REFRESH           = 0x004
M_SEND              = 0x006   # Indication
M_DATA_INDICATION   = 0x007
M_CREATE_PERMISSION = 0x008
M_CHANNEL_BIND      = 0x009

# Attributes
ATTR_USERNAME                  = 0x0006
ATTR_MESSAGE_INTEGRITY         = 0x0008
ATTR_ERROR_CODE                = 0x0009
ATTR_UNKNOWN_ATTRIBUTES        = 0x000A
ATTR_CHANNEL_NUMBER            = 0x000C
ATTR_LIFETIME                  = 0x000D
ATTR_XOR_PEER_ADDRESS          = 0x0012
ATTR_DATA                      = 0x0013
ATTR_REALM                     = 0x0014
ATTR_NONCE                     = 0x0015
ATTR_REQUESTED_ADDR_FAMILY     = 0x0017  # 0x01=v4, 0x02=v6
ATTR_EVEN_PORT                 = 0x0018  # 1 byte (R bit), 3 RFFU
ATTR_REQUESTED_TRANSPORT       = 0x0019  # 17=UDP
ATTR_DONT_FRAGMENT             = 0x001A
ATTR_RESERVATION_TOKEN         = 0x0022
ATTR_FINGERPRINT               = 0x8028
ATTR_SOFTWARE                  = 0x8022

# Channel number range
CHAN_MIN = 0x4000
CHAN_MAX = 0x7FFF

# ---------- Helpers ----------

def msg_type(method: int, klass: int) -> int:
    """
    STUN message type field: method bits interleaved with class bits.
    class: 00=req, 01=indication, 10=success, 11=error
    """
    t = (method & 0x000F)
    t |= (method & 0x0070) << 1
    t |= (method & 0x0F80) << 2
    if klass & 0x1: t |= (1 << 4)
    if klass & 0x2: t |= (1 << 8)
    return t

def build_attr(attr_type: int, value: bytes) -> bytes:
    return struct.pack("!HH", attr_type, len(value)) + value + (b"\x00" * ((4 - (len(value) % 4)) % 4))

def build_header(msg_type_u16: int, body: bytes, txn_id: bytes) -> bytes:
    assert len(txn_id) == 12
    return struct.pack("!HHI", msg_type_u16, len(body), STUN_MAGIC_COOKIE) + txn_id + body

def crc32(data: bytes) -> int:
    return binascii.crc32(data) & 0xFFFFFFFF

def md5_bytes(s: str) -> bytes:
    return hashlib.md5(s.encode("utf-8")).digest()

def hmac_sha1(key: bytes, data: bytes) -> bytes:
    return hmac.new(key, data, hashlib.sha1).digest()

def random_tid() -> bytes:
    return os.urandom(12)

# ---------- Attribute builders ----------

def attr_requested_transport_udp() -> bytes:
    return build_attr(ATTR_REQUESTED_TRANSPORT, struct.pack("!Bxxx", 17))

def attr_xor_peer_address_ipv4(ip: str, port: int) -> Tuple[int, bytes]:
    xport = port ^ (STUN_MAGIC_COOKIE >> 16)
    ip_bytes = socket.inet_aton(ip)
    cookie_bytes = struct.pack("!I", STUN_MAGIC_COOKIE)
    xip = bytes(a ^ b for (a, b) in zip(ip_bytes, cookie_bytes))
    return xport, xip

def attr_xor_peer_address(ip: str, port: int) -> bytes:
    xport, xip = attr_xor_peer_address_ipv4(ip, port)
    val = struct.pack("!BBH4s", 0x00, 0x01, xport, xip)
    return build_attr(ATTR_XOR_PEER_ADDRESS, val)

def attr_data(payload: bytes) -> bytes:
    return build_attr(ATTR_DATA, payload)

def attr_username(u: bytes) -> bytes:
    return build_attr(ATTR_USERNAME, u)

def attr_realm(r: bytes) -> bytes:
    return build_attr(ATTR_REALM, r)

def attr_nonce(n: bytes) -> bytes:
    return build_attr(ATTR_NONCE, n)

def attr_lifetime(seconds: int) -> bytes:
    return build_attr(ATTR_LIFETIME, struct.pack("!I", seconds))

def attr_channel_number(ch: int) -> bytes:
    return build_attr(ATTR_CHANNEL_NUMBER, struct.pack("!H2x", ch))

def attr_dont_fragment() -> bytes:
    return build_attr(ATTR_DONT_FRAGMENT, b"")

def attr_requested_addr_family(fam: int) -> bytes:
    return build_attr(ATTR_REQUESTED_ADDR_FAMILY, struct.pack("!Bxxx", fam))

def attr_even_port(rbit: int) -> bytes:
    return build_attr(ATTR_EVEN_PORT, struct.pack("!Bxxx", 1 if rbit else 0))

def attr_software(s: bytes=b"turn-variety") -> bytes:
    return build_attr(ATTR_SOFTWARE, s)

def attr_fingerprint(value_u32: int) -> bytes:
    return build_attr(ATTR_FINGERPRINT, struct.pack("!I", value_u32))

# ---------- Message composition with MI / FP ----------

def compute_key(auth_mode: str, username: str, realm: str, password: str) -> bytes:
    if auth_mode == "long":
        return md5_bytes(f"{username}:{realm}:{password}")
    elif auth_mode == "short":
        return password.encode("utf-8")
    else:
        raise ValueError("auth_mode must be 'long' or 'short'")

def build_message(method: int,
                  klass: int,
                  txn_id: bytes,
                  attrs_before_mi: List[bytes],
                  mi_key: Optional[bytes]=None,
                  include_fingerprint: bool=False) -> bytes:
    """
    Compose a STUN message with the correct MESSAGE-INTEGRITY and FINGERPRINT ordering.
    """
    body = b"".join(attrs_before_mi)
    mtype = msg_type(method, klass)

    # Start with header + body
    msg = build_header(mtype, body, txn_id)

    if mi_key is not None:
        mi_attr_hdr = struct.pack("!HH", ATTR_MESSAGE_INTEGRITY, 20)
        body_with_mi = body + mi_attr_hdr + (b"\x00" * 20)
        msg = build_header(mtype, body_with_mi, txn_id)
        to_hmac = msg[:-20]  # up to (excluding) MI value
        mac = hmac_sha1(mi_key, to_hmac)
        msg = msg[:-20] + mac

    if include_fingerprint:
        c = crc32(msg) ^ 0x5354554E
        fp_attr = attr_fingerprint(c)
        body_now = msg[STUN_HEADER_SIZE:] + fp_attr
        msg = build_header(mtype, body_now, txn_id)

    return msg

# ---------- Minimal STUN parser (for 401 handling) ----------

def parse_stun_attrs(data: bytes) -> Dict[int, List[bytes]]:
    attrs: Dict[int, List[bytes]] = {}
    if len(data) < STUN_HEADER_SIZE:
        return attrs
    total_len = struct.unpack_from("!H", data, 2)[0]
    if len(data) < STUN_HEADER_SIZE + total_len:
        total_len = max(0, len(data) - STUN_HEADER_SIZE)
    pos = STUN_HEADER_SIZE
    end = STUN_HEADER_SIZE + total_len
    while pos + 4 <= end:
        atype, alen = struct.unpack_from("!HH", data, pos)
        pos += 4
        aval = data[pos:pos+alen]
        pos += alen
        if pos % 4 != 0:
            pos += (4 - (pos % 4))
        attrs.setdefault(atype, []).append(aval)
    return attrs

def parse_type_and_class(data: bytes) -> Tuple[int, int]:
    if len(data) < 2: return (0, 0)
    t = struct.unpack_from("!H", data, 0)[0]
    klass = ((t >> 9) & 0x2) | ((t >> 4) & 0x1)
    return t, klass

# ---------- PCAP capture helpers ----------

def pick_iface_for_dst(dst_ip: str) -> str:
    tmp = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        tmp.connect((dst_ip, 9))
        local_ip = tmp.getsockname()[0]
    finally:
        tmp.close()
    for iface in get_if_list():
        try:
            if get_if_addr(iface) == local_ip:
                return iface
        except Exception:
            pass
    for iface in get_if_list():
        if iface != "lo":
            return iface
    return get_if_list()[0]

def capture_pcap_async(iface: str, bpf: str, duration: float, out_path: str):
    pkts = []
    def _sniff():
        nonlocal pkts
        pkts = sniff(iface=iface, filter=bpf, timeout=duration)
    th = threading.Thread(target=_sniff, daemon=True)
    th.start()
    return th, lambda: wrpcap(out_path, pkts)

# ---------- Builders for specific requests ----------

def build_binding_request(txn_id: bytes, add_fp: bool=False) -> bytes:
    attrs = [attr_software()]
    return build_message(M_BINDING, 0b00, txn_id, attrs, None, include_fingerprint=add_fp)

def build_allocate_request(txn_id: bytes,
                           requested_family: int = 0,
                           add_df: bool=False,
                           even_port: Optional[int]=None,
                           add_fp: bool=False,
                           mi_key: Optional[bytes]=None) -> bytes:
    attrs = [attr_requested_transport_udp(), attr_software()]
    if requested_family in (1, 2):
        attrs.append(attr_requested_addr_family(requested_family))
    if add_df:
        attrs.append(attr_dont_fragment())
    if even_port is not None:
        attrs.append(attr_even_port(even_port))
    return build_message(M_ALLOCATE, 0b00, txn_id, attrs, mi_key, include_fingerprint=add_fp)

def build_create_permission_request(txn_id: bytes, peers: List[Tuple[str,int]], add_fp: bool=False, mi_key: Optional[bytes]=None) -> bytes:
    attrs = []
    for ip, port in peers:
        attrs.append(attr_xor_peer_address(ip, port))
    attrs.append(attr_software())
    return build_message(M_CREATE_PERMISSION, 0b00, txn_id, attrs, mi_key, include_fingerprint=add_fp)

def build_channel_bind_request(txn_id: bytes, channel: int, peer_ip: str, peer_port: int, add_fp: bool=False, mi_key: Optional[bytes]=None) -> bytes:
    attrs = [attr_channel_number(channel), attr_xor_peer_address(peer_ip, peer_port), attr_software()]
    return build_message(M_CHANNEL_BIND, 0b00, txn_id, attrs, mi_key, include_fingerprint=add_fp)

def build_send_indication(txn_id: bytes, peer_ip: str, peer_port: int, data: bytes, add_df: bool=False, add_fp: bool=False) -> bytes:
    attrs = [attr_xor_peer_address(peer_ip, peer_port), attr_data(data), attr_software()]
    if add_df:
        attrs.append(attr_dont_fragment())
    return build_message(M_SEND, 0b01, txn_id, attrs, None, include_fingerprint=add_fp)

def build_refresh_request(txn_id: bytes, lifetime_sec: int, add_fp: bool=False, mi_key: Optional[bytes]=None) -> bytes:
    attrs = [attr_lifetime(lifetime_sec), attr_software()]
    return build_message(M_REFRESH, 0b00, txn_id, attrs, mi_key, include_fingerprint=add_fp)

def build_channel_data(channel: int, payload: bytes) -> bytes:
    hdr = struct.pack("!HH", channel, len(payload))
    pad = b"\x00" * ((4 - (len(payload) % 4)) % 4)
    return hdr + payload + pad

# ---------- Socket helpers ----------

def recv_stun_once(sock: socket.socket, timeout: float) -> Optional[bytes]:
    sock.settimeout(timeout)
    try:
        data, _ = sock.recvfrom(2048)
        if len(data) >= STUN_HEADER_SIZE and data[4:8] == struct.pack("!I", STUN_MAGIC_COOKIE):
            return data
        return None
    except socket.timeout:
        return None

# ---------- Seed dump helper ----------

class SeedDumper:
    def __init__(self, seed_dir: Optional[str]):
        self.dir = seed_dir
        self.idx = 0
        if self.dir:
            os.makedirs(self.dir, exist_ok=True)

    def dump(self, name: str, data: bytes):
        if not self.dir:
            return
        self.idx += 1
        fn = os.path.join(self.dir, f"{self.idx:02d}-{name}.bin")
        with open(fn, "wb") as f:
            f.write(data)
        print(f"[seed] wrote {fn} ({len(data)} bytes)")

# ---------- Main flow ----------

def main():
    ap = argparse.ArgumentParser(description="Send varied STUN/TURN (UDP) messages and capture a PCAP.")
    ap.add_argument("--server", default="127.0.0.1", help="TURN server IP")
    ap.add_argument("--port", type=int, default=3478, help="TURN server UDP port")
    ap.add_argument("--iface", default="auto", help="Interface to sniff (auto|any|lo|eth0...)")
    ap.add_argument("--pcap", default="turn-variety.pcap", help="Output PCAP path")
    ap.add_argument("--timeout", type=float, default=4.0, help="Sniff/socket timeout (seconds)")
    ap.add_argument("--sleep", type=float, default=0.25, help="Sleep between steps (seconds)")

    ap.add_argument("--tid", default="", help="Transaction ID (24 hex chars). Empty = random per message.")
    ap.add_argument("--local-port", type=int, default=59000, help="Local UDP port to bind for clearer PCAP")

    # Peers (repeatable)
    ap.add_argument("--peer", action="append", default=[], help="Peer as IP:port (repeatable). Example: 172.30.0.11:59000")

    # What to send (choose any; --send-all toggles a good default sequence)
    ap.add_argument("--send-binding", action="store_true", help="Send Binding Request")
    ap.add_argument("--send-allocate", action="store_true", help="Send Allocate (unauth unless auth flags provided)")
    ap.add_argument("--send-create-perm", action="store_true", help="Send CreatePermission for all --peer entries")
    ap.add_argument("--send-channelbind", action="store_true", help="Send ChannelBind to first --peer with --channel")
    ap.add_argument("--send-indication", action="store_true", help="Send Send Indication to first --peer")
    ap.add_argument("--send-channeldata", action="store_true", help="Send raw ChannelData to first --peer")
    ap.add_argument("--send-refresh", action="store_true", help="Send Refresh (0 to delete, or positive seconds)")
    ap.add_argument("--send-all", action="store_true", help="Send a reasonable full sequence")

    # Options & knobs
    ap.add_argument("--requested-family", type=int, default=0, choices=[0,1,2], help="REQUESTED-ADDRESS-FAMILY (0=omit, 1=IPv4, 2=IPv6)")
    ap.add_argument("--dont-fragment", action="store_true", help="Add DONT-FRAGMENT to Allocate and Send Indication")
    ap.add_argument("--even-port", type=int, choices=[0,1], default=None, help="Add EVEN-PORT to Allocate (0 or 1)")
    ap.add_argument("--channel", type=lambda x: int(x,0), default=0x4001, help="Channel number (e.g., 0x4001)")
    ap.add_argument("--data", default="hello over turn", help="Payload string for Send Indication / ChannelData")
    ap.add_argument("--data-len", type=int, default=0, help="If >0, override payload size with this many 'A' bytes")
    ap.add_argument("--refresh-lifetime", type=int, default=0, help="lifetime seconds for Refresh (0 deletes allocation)")
    ap.add_argument("--fingerprint", action="store_true", help="Include FINGERPRINT where applicable")
    ap.add_argument("--omit-pcap", action="store_true", help="Disable sniff + pcap writing")

    # Seed dumping
    ap.add_argument("--seed-dir", default="", help="If set, write each sent request to this directory for AFLNet seeds")

    # Auth
    ap.add_argument("--username", default="", help="Username for auth (optional)")
    ap.add_argument("--password", default="", help="Password for auth (optional)")
    ap.add_argument("--realm", default="", help="Realm (if known). If empty and --auto-auth, it will be discovered.")
    ap.add_argument("--nonce", default="", help="Nonce (if known). If empty and --auto-auth, it will be discovered.")
    ap.add_argument("--auth-mode", choices=["long","short"], default="long", help="Auth mode for MESSAGE-INTEGRITY key")
    ap.add_argument("--auto-auth", action="store_true", help="Perform unauth Allocate, parse 401 REALM/NONCE, retry with MI")

    args = ap.parse_args()

    # Resolve peers
    peers: List[Tuple[str,int]] = []
    for p in args.peer:
        try:
            ip, port_s = p.rsplit(":", 1)
            peers.append((ip, int(port_s)))
        except Exception:
            raise SystemExit(f"Bad --peer format: {p} (expected IP:port)")

    # If --send-all, enable a comprehensive path
    if args.send_all:
        args.send_binding = True
        args.send_allocate = True
        if peers:
            args.send_create_perm = True
            args.send_channelbind = True
            args.send_indication = True
            args.send_channeldata = True
        args.send_refresh = True

    # Data payload
    payload = (b"A" * args.data_len) if args.data_len > 0 else args.data.encode("utf-8")

    # Transaction ID strategy
    fixed_tid: Optional[bytes] = None
    if args.tid:
        try:
            fixed_tid = bytes.fromhex(args.tid)
        except ValueError:
            raise SystemExit("Transaction ID must be 24 hex chars (12 bytes).")
        if len(fixed_tid) != 12:
            raise SystemExit("Transaction ID must be 24 hex chars (12 bytes).")

    def tid() -> bytes:
        return fixed_tid if fixed_tid is not None else random_tid()

    # Interface + BPF
    iface = pick_iface_for_dst(args.server) if args.iface.lower() in ("auto", "any", "", "default") else args.iface
    bpf = f"udp and host {args.server} and port {args.port}"

    # Prepare socket
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    s.bind(("0.0.0.0", args.local_port))
    server = (args.server, args.port)

    # Seed dumper
    seeder = SeedDumper(args.seed_dir if args.seed_dir else None)

    # Start capture
    if not args.omit_pcap:
        th, save_pcap = capture_pcap_async(iface, bpf, args.timeout, args.pcap)
        time.sleep(0.10)
    else:
        th, save_pcap = None, None

    print(f"[i] Using iface={iface}, capturing to '{args.pcap}'" + (" (disabled)" if args.omit_pcap else ""))
    print(f"[i] Server {args.server}:{args.port}, local_port={args.local_port}")
    print(f"[i] Peers: {peers if peers else '[]'}")

    # 1) Binding
    if args.send_binding:
        print("[*] Sending Binding Request")
        pkt = build_binding_request(tid(), add_fp=args.fingerprint)
        s.sendto(pkt, server)
        seeder.dump("binding", pkt)
        time.sleep(args.sleep)

    # Prepare MI key if provided (manual route)
    mi_key_manual: Optional[bytes] = None
    if args.username and args.password and args.realm and args.nonce:
        mi_key_manual = compute_key(args.auth_mode, args.username, args.realm, args.password)

    # 2) Allocate (various modes)
    mi_key_for_allocate: Optional[bytes] = None
    used_realm = args.realm
    used_nonce = args.nonce

    if args.auto_auth and args.username and args.password:
        print("[*] Auto-auth Allocate step 1 (unauth) ...")
        unauth_tid = tid()
        unauth = build_allocate_request(unauth_tid,
                                        requested_family=args.requested_family,
                                        add_df=args.dont_fragment,
                                        even_port=args.even_port,
                                        add_fp=args.fingerprint,
                                        mi_key=None)
        s.sendto(unauth, server)
        seeder.dump("allocate-unauth", unauth)
        resp = recv_stun_once(s, args.timeout)
        if resp:
            _, klass = parse_type_and_class(resp)
            attrs = parse_stun_attrs(resp)
            if klass == 0b11 and (ATTR_REALM in attrs) and (ATTR_NONCE in attrs):
                used_realm = attrs[ATTR_REALM][0].decode(errors="ignore")
                used_nonce = attrs[ATTR_NONCE][0].decode(errors="ignore")
                print(f"[+] Got 401 challenge with REALM='{used_realm}', NONCE='{used_nonce}'")
                mi_key_for_allocate = compute_key(args.auth_mode, args.username, used_realm, args.password)
            else:
                print("[!] No REALM/NONCE found; proceeding without MI.")
        else:
            print("[!] No response to unauth Allocate; proceeding nonetheless.")

    elif mi_key_manual is not None:
        mi_key_for_allocate = mi_key_manual

    if args.send_allocate:
        print("[*] Sending Allocate " + ("with MI" if mi_key_for_allocate else "(unauth)"))
        attrs = [attr_requested_transport_udp(), attr_software()]
        if args.requested_family in (1,2):
            attrs.append(attr_requested_addr_family(args.requested_family))
        if args.dont_fragment:
            attrs.append(attr_dont_fragment())
        if args.even_port is not None:
            attrs.append(attr_even_port(args.even_port))
        if mi_key_for_allocate and args.username:
            attrs.insert(0, attr_username(args.username.encode("utf-8")))
        if mi_key_for_allocate and used_realm:
            attrs.insert(1, attr_realm(used_realm.encode("utf-8")))
        if mi_key_for_allocate and used_nonce:
            attrs.insert(2, attr_nonce(used_nonce.encode("utf-8")))
        pkt = build_message(M_ALLOCATE, 0b00, tid(), attrs, mi_key_for_allocate, include_fingerprint=args.fingerprint)
        s.sendto(pkt, server)
        seeder.dump("allocate", pkt)
        time.sleep(args.sleep)

    # 3) CreatePermission
    if args.send_create_perm and peers:
        print(f"[*] Sending CreatePermission for {len(peers)} peer(s)")
        pkt = build_create_permission_request(tid(), peers, add_fp=args.fingerprint, mi_key=mi_key_for_allocate)
        s.sendto(pkt, server)
        seeder.dump("create-permission", pkt)
        time.sleep(args.sleep)

    # 4) ChannelBind
    if args.send_channelbind and peers:
        ch = args.channel
        if not (CHAN_MIN <= ch <= CHAN_MAX):
            print(f"[!] Channel {hex(ch)} out of range; using 0x4001")
            ch = 0x4001
        print(f"[*] Sending ChannelBind (channel={hex(ch)}) to {peers[0]}")
        pkt = build_channel_bind_request(tid(), ch, peers[0][0], peers[0][1], add_fp=args.fingerprint, mi_key=mi_key_for_allocate)
        s.sendto(pkt, server)
        seeder.dump("channelbind", pkt)
        time.sleep(args.sleep)

    # 5) Send Indication
    if args.send_indication and peers:
        print(f"[*] Sending Send Indication to {peers[0]}; payload {len(payload)}B")
        pkt = build_send_indication(tid(), peers[0][0], peers[0][1], payload, add_df=args.dont_fragment, add_fp=args.fingerprint)
        s.sendto(pkt, server)
        seeder.dump("send-indication", pkt)
        time.sleep(args.sleep)

    # 6) ChannelData
    if args.send_channeldata and peers:
        ch = args.channel if (CHAN_MIN <= args.channel <= CHAN_MAX) else 0x4001
        cd = build_channel_data(ch, payload)
        print(f"[*] Sending ChannelData (channel={hex(ch)}, {len(cd)}B on wire) to {peers[0]}")
        s.sendto(cd, server)
        seeder.dump("channeldata", cd)
        time.sleep(args.sleep)

    # 7) Refresh
    if args.send_refresh:
        print(f"[*] Sending Refresh (lifetime={args.refresh_lifetime}s)")
        pkt = build_refresh_request(tid(), args.refresh_lifetime, add_fp=args.fingerprint, mi_key=mi_key_for_allocate)
        s.sendto(pkt, server)
        seeder.dump("refresh", pkt)
        time.sleep(args.sleep)

    # Cleanup / finalize PCAP
    s.close()
    if th is not None:
        th.join(timeout=args.timeout + 1.0)
        save_pcap()  # type: ignore
        print(f"[+] Wrote PCAP to {args.pcap}")

    print("[i] Tip: In Wireshark, right-click UDP 3478 and 'Decode As... -> STUN'. ChannelData shows as raw.")

if __name__ == "__main__":
    main()

'''./script.py \
  --server 127.0.0.1 --port 3478 \
  --peer 172.30.0.11:59000 \
  --send-all \
  --seed-dir seeds \
  --pcap turn-variety.pcap'''