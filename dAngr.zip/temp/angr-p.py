import angr
import claripy
import cloudpickle as pickle

import dAngr
from dAngr.angr_ext.std_tracker import StdTracker


with open("file_state_4", "rb") as f:
    state = pickle.load(f)

print(list(state.plugins.keys()))

print(type(state))


# safety checks
active = getattr(state, "_active_plugins", {})
if "stdout_tracker" in active and not hasattr(state, "stdout_tracker"):
    # Repair inconsistent state: rebuild the attribute from the mapping
    setattr(state, "stdout_tracker", active["stdout_tracker"])

# Now (re)register safely
if state.has_plugin("stdout_tracker"):
    # Normal case: plugin is active and consistent
    state.release_plugin("stdout_tracker")

state.register_plugin("stdout_tracker", StdTracker())

proj = state.project
print(list(state.plugins.keys()))
simgr = angr.SimulationManager(project=proj, active_states=[state])
#sigme
simgr.run()

'''proj = angr.Project("turnserver", auto_load_libs=False)
load_options={
        "main_opts": {
            "base_addr": 0x400000,   
        }
    }
state = proj.factory.entry_state(args=["turnserver", "-c", "./turnserver.conf"], load_options=load_options)

state.options.add(angr.options.ZERO_FILL_UNCONSTRAINED_MEMORY)
state.options.add(angr.options.ZERO_FILL_UNCONSTRAINED_REGISTERS)


# Create a symbolic representation of the configuration file
with open("turnserver.conf", "rb") as f:
    concrete_conf = f.read()

CONF_SIZE = len(concrete_conf)

conf_sym = claripy.BVS("turnserver_conf", CONF_SIZE * 8)

# Constrain each byte to match the concrete config
for i, b in enumerate(concrete_conf):
    state.solver.add(conf_sym.get_byte(i) == b)

conf_file = angr.SimFile(
    "turnserver.conf",
    content=conf_sym,
    size=CONF_SIZE,
)

state.fs.insert("turnserver.conf", conf_file)'''

