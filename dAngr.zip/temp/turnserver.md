int main(unsigned long long a0, unsigned long long *a1)

```
load './turnserver' base_addr=0x0400000 history_cache_state=5

uf

set_entry_state args=["turnserver", "-c", "./turnserver.conf"]


x=$(cat turnserver.conf)
create_symbolic_file "turnserver.conf" content=&vars.x


def skip():
    return 0

var_pass = 0
def pass():
    if var_pass == 0:
        var_pass = 1
        &reg.eax = 99
    else:
        var_pass = 0
        &reg.eax = -1

def set_cpu():
    &reg.rax = 2

def skip_one():
    &reg.rax = 1

def set_time():
    &reg.eax = 0x690B0EAF

def setrlimit_stub():
    &reg.eax = 0

def getrlimit_stub(arg0, p_rlim):
    rlim_cur = p_rlim
    rlim_max = (p_rlim + 4)
    set_memory rlim_cur 1024 4
    set_memory rlim_max 1024 4
    &reg.eax = 0

def getcwd_stub(buffer, size):
    !(import os)
    path = to_int !(f'0x{os.getcwd().encode('utf-8').hex()}')
    size_path = to_int !(int(len(os.getcwd().encode('utf-8').hex())/2))
    set_memory buffer &vars.path size_path
    &reg.rax = buffer

def inet_pton_stub(type, source_addr, dest_addr):
    type_int = !(int.from_bytes((&vars.type).encode('latin1'), 'big'))

    str = "type of inet_pton is not 2 or 10, it is " + (to_str type_int)
    assertion !(&vars.type_int==2 or &vars.type_int==10) str
    
    if type_int == 2:
        value = (get_memory source_addr 9)

        !(x = (&vars.value).strip("\x00"))
        !(import socket)
        !(x = socket.inet_aton(x))
        value_dest = !(int.from_bytes(x, "big"))
        
        set_memory dest_addr value_dest 4

        &reg.eax = 1

    if type_int == 10:
        assertion False

def ntohs_stub(arg0):
    &reg.rax = arg0

def getifaddrs_stub(arg):
    addr_ifs = &reg.rbp - 0x50
    heap_location = malloc 32
    set_memory addr_ifs heap_location 8

    set_memory heap_location 0x020000007F000001000000000000000002000000AC11000E0000000000000000 32


def skip_blanks_stub(ptr):
    ptr = &reg.rbp - 0x840
    offset = 0
    ptr_off = ptr + offset

    value = get_memory ptr_off 1
    value1 = get_memory (ptr_off + 1) 1
    value2 = get_memory (ptr_off + 2) 1
    value3 = get_memory (ptr_off + 3) 1
    

    if !(&vars.value == '\x00' or &vars.value1 == '\x00' or &vars.value2 == '\x00' or &vars.value3 == '\x00'):
        i = 0
        while i != 50:
            ptr_value = ptr_off + i
            i = i + 1

            value = get_memory ptr_value 1
            value1 = get_memory (ptr_value + 1) 1
            value2 = get_memory (ptr_value + 2) 1
            value3 = get_memory (ptr_value + 3) 1

            if i == 50:
                y = get_memory ptr_value 100
                !print(&vars.y)
                assertion False

            if !(&vars.value != '\x00' and &vars.value1 != '\x00' and &vars.value2 != '\x00' and &vars.value3 != '\x00'):
                ptr = ptr_value
                i = 50


    value = get_memory ptr 1

    run_loop = False
    if !(&vars.value == '\x20'):
        run_loop = True
    if !(&vars.value == '\x90'):
        run_loop = True
    if !(&vars.value == '\x0a'):
        run_loop = True

    while run_loop == True:
        ptr = ptr + 1

        value = get_memory ptr 1

        print &vars.value

        run_loop = False
        if !(&vars.value == '\x20'):
            run_loop = True
        if !(&vars.value == '\x90'):
            run_loop = True
        if !(&vars.value == '\x0a'):
            run_loop = True

    
    &reg.rax = ptr

def set_integrity_check_key(password, type, upwd, ptr_key, algoritme):
    set_memory ptr_key 0x2c82ea35dc829130f5ba0ad730141482 16

def turn_random_stub():
    &reg.rax = 0x1111111111111111

def turn_event_base_stub():
    heap_location = malloc 664
    set_memory heap_location 0xa046fbf7ff7f00008095555555550000000000000000000000000000000000002047fbf7ff7f0000000000000000000000000000000000009000000200000000b0e8f8f7ff7f0000e092555555550000ffffffff0000000000000000000000000400000000000000e09255555555000000000000000000000000000000000000000000000000000000000000000000001200000000000000000000000000000000000000000000000400000005000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000309755555555000001000000000000000000000000000000e89355555555000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000600000000000000000000000000000000000000000000000000000000000000000000000000000018ebc36800000000cc600c0000000000f2ff4d0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000200000000000000ffffffffffffffff0000000000000000ffffff7fffffff7f00000000ffffffffffffffff000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000 664

    &reg.rax = heap_location

def event_base_init_common_timeout_stub():
    heap_location = malloc 16
    set_memory heap_location 0x050000000000000040e2015000000000 16
    &reg.rax = heap_location


counter = 0
def fgets_stub(ptr_buffer, size, file):
    list = ["listening-ip=127.0.0.1","relay-ip=127.0.0.1","realm=test-server","listening-port=3478","stale-nonce=0", "min-port=50000", "max-port=50100", "allow-loopback-peers", "no-cli", "no-dtls", "relay-threads=0", "cpus=1", "lt-cred-mech", "user=attacker:password"]

    size = to_int &reg.rsi
    set_memory &reg.rdi 0 size

    if counter != -1:
        list_size = !(len(&vars.list))
        if list_size != counter:
            data_size = !(len(&vars.list[&vars.counter]))

            set_memory &reg.rdi list[counter] data_size
            &reg.rax = &reg.rdi
            counter = counter + 1
        else:
            counter = 0


    if counter == 0:
        &reg.rax = 0

def evconnlistener_new_stub():
    &reg.rax = 1

hook_function skip 'THREAD_setup'
hook_function skip 'turn_mutex_init'
hook_function skip 'init_domain'
hook_function skip 'turn_mutex_init_recursive'
hook_function skip 'turn_mutex_lock'
hook_function skip 'turn_mutex_unlock'
hook_function pass 'getopt_long'
hook_function set_cpu 'get_system_active_number_of_cpus'
hook_function set_time 'time'
hook_function set_time 'log_time'
hook_function skip 'ignore_sigpipe'
hook_function setrlimit_stub 'setrlimit'
hook_function getrlimit_stub 'getrlimit'
hook_function getcwd_stub 'getcwd'
hook_function skip 'openssl_setup'
hook_function inet_pton_stub 'inet_pton'
hook_function ntohs_stub 'ntohs'
hook_function getifaddrs_stub 'getifaddrs'

hook_function turn_random_stub 'turn_random'

hook_function skip 'turn_log_func_default'

hook_function set_integrity_check_key 'stun_produce_integrity_key_str'
hook_function turn_event_base_stub 'turn_event_base_new'
hook_function event_base_init_common_timeout_stub 'event_base_init_common_timeout'
hook_function skip_one 'pthread_barrier_init'
hook_function setrlimit_stub 'socket_eintr'
hook_function setrlimit_stub 'bind'
hook_function setrlimit_stub 'fcntl'
hook_region fgets_stub 0x4197ae 5

hook_function evconnlistener_new_stub 'evconnlistener_new'
hook_function setrlimit_stub 'pthread_barrier_wait'

def check_states():
    state_len = len &(list_states)
    state_len > 1

breakpoint (make_filter check_states)

ba 0x41c1da
ba 0x00422c8b

ba 0x041b115

run


is

evconnlistener_new(...) returns a pointer to a listener object:
On success: a non-NULL struct evconnlistener* (your peVar4).
On failure: NULL (and errno is typically set by the failing underlying call like listen(), fcntl(), or memory allocation).
You free it with evconnlistener_free(listener), and you can get the underlying fd with evconnlistener_get_fd(listener).

      peVar4 = (evconnlistener *)
               evconnlistener_new(server->e->event_base,server_input_handler,server,10,0x400,iVa r2);

    address: 0x00438829

run

is
```






get_memory (&reg.rbp - 0x840) 1025
get_memory (&reg.rax) 1025

## see registers

print &reg.rdi
print &reg.rsi
print &reg.rdx
print &reg.rcx
print &reg.r8


load './turnserver_dyn'
fi 0x416739

load './turnserver_static'
fi main


single_step
single_step
single_step
single_step
single_step
single_step
single_step
single_step
single_step
single_step
single_step
single_step
single_step
single_step
single_step
single_step