from .CommandError import CommandError

class ParseError(CommandError):
    """Exception raised for parsing errors."""
    pass

