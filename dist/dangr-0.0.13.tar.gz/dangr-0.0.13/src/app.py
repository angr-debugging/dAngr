from dAngr.run import run

if __name__ == "__main__":
    # parse_input("load lib14_angr_shared_library.so 0x4000000")
    run()

