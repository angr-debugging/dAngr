from .CommandError import CommandError


class DebuggerCommandError(CommandError):
    """Exception raised for debugger command errors."""
    pass