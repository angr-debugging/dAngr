from .CommandError import CommandError

class ValueError(CommandError):
    """Exception raised for invalid values."""
    pass

